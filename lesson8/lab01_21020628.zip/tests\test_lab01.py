"""LAB 1 — add your five tests here. Do not delete the smoke tests.

A. GET /books, empty database -> HTTP 200 and []
B. GET /books/9999 -> HTTP 404, JSON code == NOT_FOUND
C. POST /books with only author -> HTTP 400, errors contains title
D. POST valid book, DELETE it, GET same id -> HTTP 404
BONUS. Validate a Book response using JSON Schema; add an unknown
       field to a *copy* of the response and assert ValidationError.

Useful imports:
    from jsonschema import validate, ValidationError
    import pytest
    from tools import get_book_schema

Do not depend on test execution order. Fixtures: client, app, sample_book.
"""
import copy
import pytest
from jsonschema import ValidationError, validate
from tools import get_book_schema


# Test A: GET /books khi CSDL rỗng trả về mảng rỗng (không phải null)
def test_get_books_empty_db(client):
    response = client.get("/books")
    assert response.status_code == 200
    assert response.is_json
    data = response.get_json()
    assert data is not None
    assert data == []


# Test B: GET /books/<id> với id không tồn tại trả về 404 + JSON chứa "code": "NOT_FOUND"
def test_get_book_not_found(client):
    response = client.get("/books/9999")
    assert response.status_code == 404
    assert response.is_json
    data = response.get_json()
    assert data.get("code") == "NOT_FOUND"


# Test C: POST /books thiếu title trả về 400 + trong errors có field "title"
def test_post_book_missing_title(client):
    response = client.post("/books", json={"author": "J.J. Geewax"})
    assert response.status_code == 400
    assert response.is_json
    data = response.get_json()
    assert "errors" in data
    error_fields = {err["field"] for err in data["errors"] if "field" in err}
    assert "title" in error_fields


# Test D: POST valid book, DELETE it, GET cùng id — phải trả về 404
def test_delete_and_get_lifecycle(client):
    create_res = client.post(
        "/books",
        json={"title": "Clean Code", "author": "Robert C. Martin", "year": 2008},
    )
    assert create_res.status_code == 201
    book_id = create_res.get_json()["id"]

    delete_res = client.delete(f"/books/{book_id}")
    assert delete_res.status_code == 204

    get_res = client.get(f"/books/{book_id}")
    assert get_res.status_code == 404


# BONUS: test_response_extra_field_blocked
# Validate response bằng jsonschema và chứng minh không lộ trường lạ (password_hash)
def test_response_extra_field_blocked(client, sample_book):
    response = client.get(f"/books/{sample_book}")
    assert response.status_code == 200
    book_data = response.get_json()

    raw_schema = get_book_schema()
    # Normalize OpenAPI 3.0 nullable fields for jsonschema library
    schema = copy.deepcopy(raw_schema)
    for prop, details in schema.get("properties", {}).items():
        if details.get("nullable"):
            prop_type = details.get("type")
            if prop == "year" and prop_type == "string":
                prop_type = "integer"
            if isinstance(prop_type, str):
                details["type"] = [prop_type, "null"]
            elif isinstance(prop_type, list) and "null" not in prop_type:
                details["type"] = prop_type + ["null"]
        elif prop == "year" and details.get("type") == "string":
            details["type"] = "integer"

    # 1. Hợp lệ: book_data từ API tuân thủ schema
    validate(instance=book_data, schema=schema)

    # 2. Bất hợp lệ: thêm trường lạ (ví dụ password_hash) vào bản sao của response
    tampered_data = dict(book_data)
    tampered_data["password_hash"] = "pbkdf2:sha256:260000$example$hash"

    # 3. Schema có additionalProperties: false -> bắt buộc raise ValidationError
    with pytest.raises(ValidationError):
        validate(instance=tampered_data, schema=schema)
